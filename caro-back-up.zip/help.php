

<!DOCTYPE html>
<html>
<head>
    <title>Caro game</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <script type="text/javascript" src="js/jquery.js"></script>
    <link rel="stylesheet" href="css/style.css" media="all">
    <script type="text/javascript">
        setTimeout(2000, function(){
            var url = window.location;
            window.location = url;
        });
    </script>
</head>
<body>
<div class="wrap">

<ul>
    <li>Hai bên thay phiên nhau đi những nước đi bằng các dấu X, O trên bàn cờ.</li>
    <li>Bên nào có đường 5 quân liền nhau trên một hàng, một cột hoặc một đường chéo là thắng. (lưu ý: bị chặng 2 đầu -> vẫn là thắng)</li>
</ul>

</div>

</body>
</html>
